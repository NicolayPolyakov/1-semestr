﻿using System;

namespace HelloApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите сумму вклада: ");
            double depositAmount = Convert.ToDouble(Console.ReadLine());
            double interestRate;
            double bonus = 15; // фиксированный бонус

            // Определение процентной ставки в зависимости от суммы вклада
            if (depositAmount < 100)
            {
                interestRate = 0.05; // 5%
            }
            else if (depositAmount >= 100 && depositAmount <= 200)
            {
                interestRate = 0.07; // 7%
            }
            else
            {
                interestRate = 0.10; // 10%
            }

            // Рассчет итоговой суммы с учетом процентов и бонусов
            double interestAmount = depositAmount * interestRate;
            double finalAmount = depositAmount + interestAmount + bonus;

            // Вывод результата
            Console.WriteLine($"Сумма вклада с учетом процентов и бонусов: {finalAmount}");
            Console.ReadKey();
        }
    }
}
