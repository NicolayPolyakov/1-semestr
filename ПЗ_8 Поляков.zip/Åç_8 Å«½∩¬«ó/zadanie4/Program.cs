﻿using System;

namespace HelloApp

{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите сумму вклада: ");
            double deposit = Convert.ToDouble(Console.ReadLine());
            double interestRate;
            double totalAmount;

            if (deposit < 100)
            {
                interestRate = 0.05; // 5%
            }
            else if (deposit >= 100 && deposit <= 200)
            {
                interestRate = 0.07; // 7%
            }
            else
            {
                interestRate = 0.10; // 10%
            }

            totalAmount = deposit + (deposit * interestRate);
            Console.WriteLine($"Сумма вклада с начисленными процентами: {totalAmount}");
            Console.ReadKey();
        }
    }
}
