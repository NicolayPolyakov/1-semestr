﻿using System;
static void Main(string[] args)
{
    int intValue = 10;
    byte byteValue = (byte)intValue;
    long longValue = intValue;
    float floatValue = intValue;
    double doubleValue = intValue;
    Console.WriteLine($"Переменная типа int = {intValue}");
    Console.WriteLine($"IIepeменная типа bуtе = {byteValue}");
    Console.WriteLine($"Переменная типа long = {longValue}");
    Console.WriteLine($"Переменная типа flоаt = {floatValue}");
    Console.WriteLine($"Переменная типа double = {doubleValue}");
}
