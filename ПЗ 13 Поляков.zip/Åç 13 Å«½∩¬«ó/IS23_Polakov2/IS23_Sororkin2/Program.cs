﻿using System;
    class Program
    {
        static void Main(string[] args)
        {
            int sum = 0;
            for (int i = 1; i <= 19; i += 2)
            {
                sum += i;
            }
            Console.WriteLine("Сумма последовательности: " + sum);
        }
    }