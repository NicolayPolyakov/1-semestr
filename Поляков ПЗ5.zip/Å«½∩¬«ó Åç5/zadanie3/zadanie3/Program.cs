﻿using System;

namespace EquationSolver
{
    class Program
    {
        static void Main(string[] args)
        {
            double x = 9;
            double result = SolveEquation(x);
            Console.WriteLine("The result of the equation 2x^2 - 3∛x, where x = 9, is: " + result);
        }
        static double SolveEquation(double x)
        {
            double firstValue = Math.Round(Math.Sign(x) * Math.Pow(Math.Abs(x), 1d / 3.0), 2);
            double secondValue = 2 * x * x - 3 * firstValue;

            return secondValue;
        }
    }
}
