﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            Form1 frm1 = this.Owner as Form1;
            string sov = "";
            if (frm1.checkBox1.Checked)
            {
                sov = "Совершенолетний(яя)";
            }
            else
            {
                sov = "Несовершенолетний(яя)";
            }

            if (frm1 != null)
            {
                label1.Text = frm1.textBox1.Text;
                label2.Text = frm1.textBox2.Text;
                label3.Text = frm1.textBox3.Text;
                label7.Text = frm1.textBox4.Text;
                label5.Text = frm1.comboBox1.SelectedItem.ToString();
                label4.Text = frm1.date.Text;
                label6.Text = sov;
                if (!string.IsNullOrEmpty(frm1.openFileDialog1.FileName))
                {
                    pictureBox1.Image = (Bitmap)Bitmap.FromFile(frm1.openFileDialog1.FileName);
                }
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
        
        }
    }
}
