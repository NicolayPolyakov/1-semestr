﻿using System;

public class Program
{
    public static void Main(string[] args)
    {
        string[] input = Console.ReadLine().Split();
        int A = int.Parse(input[0]);
        int B = int.Parse(input[1]);

        int countNegativeOh = 0;

        for (int i = A; i <= B; i++)
        {
            if (IsOhNegative(i))
            {
                countNegativeOh++;
            }
        }

        Console.WriteLine(countNegativeOh);
    }

    static bool IsOhNegative(int number)
    {
        string hexNumber = Convert.ToString(number, 6);


        if (hexNumber.Length <= 2)
        {
            return false;
        }


        char penultimateDigit = hexNumber[hexNumber.Length - 2];
        char lastDigit = hexNumber[hexNumber.Length - 1];


        if (penultimateDigit == '5')
        {
            penultimateDigit = '0';
            lastDigit = (lastDigit % 2 == 0) ? (char)(lastDigit + 1) : (char)(lastDigit - 1);
        }
        else
        {
            penultimateDigit = (char)(penultimateDigit + 1);
        }


        string newHexNumber = hexNumber.Substring(0, hexNumber.Length - 2) + penultimateDigit + lastDigit;
        int newNumber = Convert.ToInt32(newHexNumber, 6);


        return number - newNumber < 0;
    }
}