﻿using System;
using static System.Console;
using static System.Math;
public class Program
{
    public static void Main()
    {
        int x, y;
        do
        {
            Write("Введите x кординат (1-8): ");
            int.TryParse(ReadLine(), out x);
            Write("Введите y кординат (1-8): ");
            int.TryParse(ReadLine(), out y);
        } while (x < 1 || x > 8 || y < 1 || y > 8);

        bool isWhite = (Abs(x + y) % 2 == 0);
        WriteLine($"Площадь в ({x}, {y}) является {(isWhite ? "белый" : "чёрный")}");
    }
}