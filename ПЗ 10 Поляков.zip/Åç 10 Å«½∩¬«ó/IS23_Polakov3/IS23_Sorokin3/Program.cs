﻿using System;
using static System.Console;
using static System.Math;

namespace rabota3
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = 3;
            double[] xValues = new double[n];

            for (int i = 0; i < n; i++)
            {
                Write("Введите значение x: ");
                xValues[i] = double.Parse(ReadLine());
            }
            for (int i = 0; i < n; i++)
            {
                double y;
                double a = xValues[i] - 3;
                y = Pow(4, 6) * Pow(a, 6) - Pow(7, 3) * Pow(a, 3) + 2;
                WriteLine($"y = {y}");
            }
        }
    }
}