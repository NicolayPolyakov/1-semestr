﻿using System;
using System.IO;

class Program
{
    static void Main(string[] args)
    {
        string[] colors = { "red", "green", "black", "white", "blue" };

        {
            foreach (string color in colors)
            {
                writer.WriteLine(color);
            }
        }
    }
}