﻿using System;
using System.IO;
class Program
{
    static void Main(string[] args)
    {
        string numbers = string.Empty;
        for (int i = 1; i <= 500; i++)
        {
            numbers += i.ToString() + ",";
        }
        numbers = numbers.TrimEnd(',');
 }
}
