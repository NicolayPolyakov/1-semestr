﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
 string name;
  System.Console.WriteLine("Введите Ваше имя: ");
            name = System.Console.ReadLine();
System.Console.WriteLine("Приветствую Вас, " + name + "!");
        }
    }
}

